#include <stdio.h>
#include <stdlib.h>
#include "str.h"
#include "tst.h"

// Longest word in a dictionary is
// 'Pneumonoultramicroscopicsilicovolcanoconiosis'
// which has 45 letters.
#define MAX_WORD_LEN 50

int main(int argc, char *argv[]) {
    // Input
    int N;
    scanf("%d\n", &N);

    TST *t = TST_create();
    String* *a = create_str_array(N);
    for (int i = 0; i < N; i++) {
        char word[MAX_WORD_LEN];
        scanf("%s", word);
        a[i] = create_string(word);
        t = TST_insert(t, a[i], i);
    }

    // Output
    //print_str_array(a, N);
    for (int i = 0; i < N; i++) {
        print_string(a[i]);
        printf(" %d\n", TST_search(t, a[i]));
    }

    destroy_str_array(a, N);
    TST_destroy(t);
}
