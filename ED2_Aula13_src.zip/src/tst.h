#ifndef TST_H
#define TST_H

#include "str.h"

// ----------------------------------------------------------------------------

typedef int Value;
#define NULL_Value -1

// ----------------------------------------------------------------------------

typedef struct node TST;
struct node {
    Value val;
    unsigned char c;
    TST *l, *m, *r;
};

TST* TST_create();
void TST_destroy(TST*);

TST* TST_insert(TST*, String*, Value);
Value TST_search(TST*, String*);

#endif
