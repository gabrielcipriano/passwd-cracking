#ifndef TRIE_H
#define TRIE_H

#include "str.h"

// ----------------------------------------------------------------------------

typedef int Value;
#define NULL_Value -1

// ----------------------------------------------------------------------------

typedef struct node Trie;

#define R 256

struct node {
    Value val;
    Trie* next[R];
};

Trie* Trie_create();
void Trie_destroy(Trie*);

Trie* Trie_insert(Trie*, String*, Value);
Value Trie_search(Trie*, String*);

#endif
