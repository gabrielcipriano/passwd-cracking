#include <stdio.h>
#include <stdlib.h>

int knowF[100000] = {[0 ... 99999] = -1};
int f(int n, int k) {
    // Implemente essa funcao para resolver a questao 1.
    if(n == 1) return knowF[0] = 1;

    if(knowF[n-1] != -1) return knowF[n - 1];
    
    return knowF[n-1] = ((f(n-1, k) + k - 1) % n) + 1;
}

int main() {
    int n, k;
    // Le a entrada.
    scanf("%d %d\n", &n, &k);

    // Calcula e exibe a saida.
    for (int i = 1; i <= n; i++) {
        printf("%d %d\n", i, f(i,k));
    } 

    return 0;
}
