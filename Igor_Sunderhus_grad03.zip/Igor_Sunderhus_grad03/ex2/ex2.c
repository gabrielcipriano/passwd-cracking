#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct {
    int s;
    int d;
    int t;
} Edge;


bool menor(Edge a, Edge b)
{
    if(a.d < b.d)
    {
        return true;
    }
    else
    {
        if(a.d == b.d)
        {
            if(a.s < b.s)
            {
                return true;
            }
            else
            {
                if(a.s == b.s)
                {
                    if(a.t < b.t)
                    {
                        return true;
                    }
                }
            }            
        }
    }
    return false;
}

// troca 
void troca(Edge*a, int i, int j)
{
    Edge aux = a[i];
    a[i] = a[j];
    a[j] = aux;
}


void sort(Edge *a, int N) {

    for(int i = 0; i < N; i++)
    {
        int min = i;
        for(int j = i+1; j<N;j++)
        {
            if(menor(a[j], a[min]))
            {
                min = j;
            }
        }

        if(min != i)
        {
            troca(a, i, min);
        }

    }
}

int main() {
    // Le a entrada.
    int N;
    scanf("%d\n", &N);
    Edge *a = malloc(N * sizeof(Edge));
    for (int i = 0; i < N; i++) {
        scanf("%d %d %d", &(a[i].s), &(a[i].d), &(a[i].t));
    }

    // Ordena.
    sort(a, N);

    // Exibe o resultado.
    for (int i = 0; i < N; i++) {
        printf("%d %d %d\n", a[i].s, a[i].d, a[i].t);
    }

    free(a);
}
