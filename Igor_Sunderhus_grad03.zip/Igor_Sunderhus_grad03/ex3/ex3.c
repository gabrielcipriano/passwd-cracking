#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

typedef struct {
    int s;
    int d;
    int t;
} Edge;


void mudar_componentes(int* componentes, int tamanho, int anterior, int novo)
{
    for(int i = 0; i < tamanho; i++)
    {
        if(componentes[i] == anterior)
        {
            componentes[i] = novo;
        }
    }
}

Edge* compute_mst(Edge *a, int M, int N) {
    // Implemente essa funcao para resolver a questao 3.
    int quant_vert = N + 1;
    int* componente = malloc(sizeof(int)* quant_vert);
    for(int j = 0; j < quant_vert; j++)
    {
        componente[j] = j + 1;
    }

    Edge* mst = malloc(sizeof(Edge)* N);

    int i = 0;
    
    while(i<N)
    {
        for(int j = 0; j < M; j++)
        {
            int s = a[j].s - 1;
            int t = a[j].t - 1;
       
            if(componente[s] != componente[t])
            {
                mst[i] = a[j];
                    mudar_componentes(componente, quant_vert, a[j].s, a[j].t);                
                    i++;

                    if(i == N) break;               
            }
        }
    }
    free(componente);
    return mst;
}

int main() {
    // Le a entrada. M eh o total de arcos a serem lidos.
    int M, N;     // N eh o numero de arcos que a MST deve ter.
    scanf("%d %d\n", &M, &N);
    Edge *a = malloc(M * sizeof(Edge));
    for (int i = 0; i < M; i++) {
        scanf("%d %d %d", &(a[i].s), &(a[i].d), &(a[i].t));
    }

    // Calcula a MST. Lembre-se que o array 'a' ja esta ordenado.
    Edge *mst = compute_mst(a, M, N);

    // Exibe o resultado.
    for (int i = 0; i < N; i++) {
        printf("%d %d %d\n", mst[i].s, mst[i].d, mst[i].t);
    }

    free(a);
    free(mst);
}
