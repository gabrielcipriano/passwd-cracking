#ifndef ITEM_H
#define ITEM_H

typedef char Key;
typedef int  Value;

#define NULL_Key   -1
#define NULL_Value -1

#endif
