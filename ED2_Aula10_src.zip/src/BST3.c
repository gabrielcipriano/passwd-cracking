#include <stdio.h>
#include <stdlib.h>
#include "ST.h"

typedef struct node Node;

struct node {
    Key key;      // Sorted by key.
    Value val;    // Associated data.
    Node *l, *r;  // Left and right subtrees.
    int size;     // Number of nodes in subtree.
};

Node *root; // Root of BST.

static Node* create_node(Key key, Value val, int size) {
    Node *n = malloc(sizeof *n);
    n->key = key;
    n->val = val;
    n->l = n->r = NULL;
    n->size = size;
    return n;
}

void ST_init(int maxN) {
    root = NULL;
}

static void rec_finish(Node *n) {
    if (n == NULL) { return; }
    rec_finish(n->l);
    rec_finish(n->r);
    free(n);
}

void ST_finish() {
    rec_finish(root);
}

static int size(Node *n);

static Node* rec_put(Node *n, Key key, Value val) {
    if (n == NULL) { return create_node(key, val, 1); }
    int cmp = compare(key, n->key);
    if      (cmp < 0) { n->l = rec_put(n->l, key, val); }
    else if (cmp > 0) { n->r = rec_put(n->r, key, val); }
    else /*cmp == 0*/ { n->val = val; }
    n->size = size(n->l) + size(n->r) + 1;
    return n;
}

void ST_put(Key key, Value val) {
    root = rec_put(root, key, val);
}

static Value rec_get(Node *n, Key key) {
    if (n == NULL) { return NULL_Value; }
    int cmp = compare(key, n->key);
    if      (cmp < 0) { return rec_get(n->l, key); }
    else if (cmp > 0) { return rec_get(n->r, key); }
    else /*cmp == 0*/ { return n->val; }
}

Value ST_get(Key key) {
    return rec_get(root, key);
}

static void rec_traverse(Node *n, void (*visit)(Key,Value)) {
    if (n == NULL) { return; }
    rec_traverse(n->l, visit);
    visit(n->key, n->val);
    rec_traverse(n->r, visit);
}

void ST_traverse(void (*visit)(Key,Value)) {
    rec_traverse(root, visit);
}

// ----------------------------------------------------------------------------
// New from BST1

bool ST_contains(Key key) {
    return ST_get(key) != NULL_Value;
}

static int size(Node *n) {
    if (n == NULL) { return 0; }
    else           { return n->size; }
}

int ST_size() {
    return size(root);
}

bool ST_empty() {
    return ST_size() == 0;
}

static Node* rec_min(Node *n) {
    if (n->l == NULL) { return n; }
    else  { return rec_min(n->l); }
}

Key ST_min() {
    return rec_min(root)->key;
}

static Node* rec_max(Node *n) {
    if (n->r == NULL) { return n; }
    else  { return rec_max(n->r); }
}

Key ST_max() {
    return rec_max(root)->key;
}

static Node* rec_floor(Node *n, Key key) {
    if (n == NULL) { return NULL; }
    int cmp = compare(key, n->key);
    if (cmp == 0) { return n; }
    if (cmp <  0) {
        return rec_floor(n->l, key);
    }
    Node *t = rec_floor(n->r, key);
    if (t != NULL) { return t; }
    else           { return n; }
}

Key ST_floor(Key key) {
    Node *n = rec_floor(root, key);
    if (n == NULL) { return NULL_Key; }
    else           { return n->key; }
}

static Node* rec_ceiling(Node *n, Key key) {
    if (n == NULL) { return NULL; }
    int cmp = compare(key, n->key);
    if (cmp == 0) { return n; }
    if (cmp <  0) {
        Node *t = rec_ceiling(n->l, key);
        if (t != NULL) { return t; }
        else           { return n; }
    }
    return rec_ceiling(n->r, key);
}

Key ST_ceiling(Key key) {
    Node *n = rec_ceiling(root, key);
    if (n == NULL) { return NULL_Key; }
    else           { return n->key; }
}

static int rec_rank(Node *n, Key key) {
  if (n == NULL) { return 0; }
  int cmp = compare(key, n->key);
  if      (cmp < 0) { return rec_rank(n->l, key); }
  else if (cmp > 0) { return 1+size(n->l)+rec_rank(n->r, key); }
  else /*cmp == 0*/ { return size(n->l); }
}
int ST_rank(Key key) {
    return rec_rank(root, key);
}

static
Node* rec_delmin(Node *n, bool del) {
    if (n->l == NULL) {
        Node *r = n->r;
        if (del) free(n);
        return r;     }
    n->l = rec_delmin(n->l, del);
    n->size = size(n->l) + size(n->r) + 1;
    return n;
}
void ST_delmin() {
    root = rec_delmin(root, true);
}

static Node* rec_delmax(Node *n) {
    if (n->r == NULL) { Node *l = n->l; free(n); return l; }
    n->r = rec_delmax(n->r);
    n->size = size(n->l) + size(n->r) + 1;
    return n;
}

void ST_delmax() {
    root = rec_delmax(root);
}

static Node* rec_delete(Node *n, Key key) {
    if (n == NULL) { return NULL; }
    int cmp = compare(key, n->key);
    if      (cmp < 0) { n->l = rec_delete(n->l, key); }
    else if (cmp > 0) { n->r = rec_delete(n->r, key); }
    else /*cmp == 0*/ {
        if (n->r == NULL) { Node *l = n->l; free(n); return l; }
        if (n->l == NULL) { Node *r = n->r; free(n); return r; }
        Node *t = n;
        n = rec_min(t->r);
        n->r = rec_delmin(t->r, false);
        n->l = t->l;
        free(t);
    }
    n->size = size(n->l) + size(n->r) + 1;
    return n;
}

void ST_delete(Key key) {
    root = rec_delete(root, key);
}
